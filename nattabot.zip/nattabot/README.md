# NattaBot — Ultimate Private Premium Discord Bot

Voice Keeper 24/7 • Natta Coins • Natta Slot • Join/Leave bergambar • Natta News (reply + mention)

Stack: Node.js ≥ 20, discord.js v14, @discordjs/voice, SQLite (better-sqlite3), @napi-rs/canvas.

## 1. Struktur folder
```
nattabot/
├─ src/
│  ├─ index.js            # entry: event, handler, backup, heartbeat
│  ├─ config.js           # konfigurasi & angka ekonomi/slot
│  ├─ db.js               # skema SQLite
│  ├─ theme.js            # embed & warna NattaBot
│  ├─ commands/           # general, economy, games, voice, admin, news
│  └─ services/           # voiceKeeper, economy, slot, cardGen, newsGen
├─ assets/news_template.jpg   # template berita (greenscreen)
├─ assets/fonts/              # taruh font .ttf di sini (opsional tapi disarankan)
├─ .env.example  ecosystem.config.js  Dockerfile  docker-compose.yml  nattabot.service
```

## 2. Mendapatkan Bot Token
1. Buka https://discord.com/developers/applications → **New Application** → beri nama *NattaBot*.
2. Menu **Bot** → **Reset Token** → salin (hanya muncul sekali). **Jangan bagikan / commit token.**
3. Di halaman Bot, aktifkan **Privileged Gateway Intents**:
   - ✅ **Server Members Intent** (pengumuman Join/Leave)
   - ✅ **Message Content Intent** (Natta News lewat mention)
4. Menu **General Information** → salin **Application ID** (= `CLIENT_ID`).
5. Undang bot: menu **OAuth2 → URL Generator**, centang scope `bot` + `applications.commands`, izin: *View Channels, Send Messages, Embed Links, Attach Files, Add Reactions, Read Message History, Connect*. Buka URL hasilnya dan pilih servermu.
6. User ID kamu (= `OWNER_ID`): Discord → Settings → Advanced → Developer Mode ON → klik kanan profilmu → Copy User ID.

## 3. Instalasi
```bash
git clone <repo-kamu> nattabot && cd nattabot     # atau upload folder ini ke VPS
npm install
cp .env.example .env && nano .env                  # isi DISCORD_TOKEN, CLIENT_ID, OWNER_ID (+ GUILD_ID)
npm start
```
Saat online, slash command otomatis terdaftar. Isi `GUILD_ID` agar langsung muncul di servermu (tanpa `GUILD_ID` = global, bisa ±1 jam).

**Font (disarankan):** unduh *Montserrat* (ExtraBold/Bold/SemiBold/Medium `.ttf`) dari Google Fonts dan taruh di `assets/fonts/`. Tanpa itu bot memakai font sistem (DejaVu/Liberation) — tetap berfungsi, hanya kurang elegan. Di Ubuntu: `sudo apt install fonts-dejavu-core fonts-liberation`.

## 4. Konfigurasi di Discord (sekali saja, sebagai admin)
| Tujuan | Perintah |
|---|---|
| Pilih voice channel | `/setvoice channel:#voice-24jam` |
| Aktifkan Voice Keeper | `/voice mode:on` |
| Channel log voice | `/setlog channel:#bot-log` |
| Channel Welcome | `/setwelcome channel:#welcome` |
| Channel Leave | `/setleave channel:#goodbye` |

Pastikan role bot punya izin **View Channel + Connect** di voice channel tujuan.

## 5. Voice Keeper 24/7
- Memakai koneksi voice resmi Discord (self-mute + self-deaf, tanpa audio) — tetap bertahan walau tidak ada orang lain.
- **Auto reconnect** dengan backoff (5 dtk → maks 2 menit), **monitor tiap 30 detik**, dan otomatis kembali bila bot dipindah/ditendang.
- Log masuk/keluar/gangguan ke console, file `logs/`, dan channel `/setlog`.
- `/voice-status` untuk cek, `/voice-reconnect` untuk paksa sambung ulang.
- Uptime sebenarnya bergantung pada hosting (lihat §8) — bot ini tidak bisa 24/7 kalau komputer/VPS mati.

## 6. Natta Coins & Slot
- Mata uang **virtual** (tanpa deposit/penarikan/nilai uang asli). Saldo awal 10.000 NC.
- `/daily` 5.000 NC + bonus streak (maks +3.000) + 10% peluang hadiah kejutan; `/weekly` 30.000 NC; chat aktif +25 NC (maks 40×/hari, cooldown 60 dtk, ditandai reaksi 🪙).
- `/transfer` 100–100.000 NC, cooldown 10 dtk, batas 500.000 NC/hari.
- Semua perubahan saldo berjalan dalam **transaksi SQLite atomik** → tidak ada duplikasi/saldo minus.
- **Slot:** taruhan 100–50.000 NC, cooldown 4 dtk. Peluang menang ±42,8% per putaran, RTP teoretis ±95,7% (dihitung otomatis dan ditampilkan di `/slotinfo`). RNG memakai `crypto.randomInt`, **tanpa manipulasi tersembunyi** berdasarkan saldo/perilaku.
- Free spin: `/freespin` (3 spin gratis per 24 jam, taruhan tetap 1.000 NC). Bonus keberuntungan harian: kemenangan pertama tiap hari +25%. Jackpot progresif: 2% taruhan masuk pool, jatuh ke 3× Lucky Seven.
- Ubah angka di `src/config.js` (bobot simbol & pengali di `src/services/slot.js`).

## 7. Natta News
1. **Reply** pesan orang yang fotonya mau dipakai.
2. Ketik: `@NattaBot - Seorang wanita pingsan saat berkendara -`
3. Bot membuat gambar HD (1472×828): foto profil orang yang di-reply menggantikan greenscreen, headline otomatis diperkecil/dibungkus agar tidak keluar area.
- Tanpa reply → bot memberi petunjuk; format salah → bot memberi contoh. Maks 120 karakter.
- Template: `classic`, `ticker`, `alert` (`/newstemplate`). Ganti gambar studio dengan menimpa `assets/news_template.jpg` (jika ukuran/posisi greenscreen berbeda, sesuaikan konstanta `GREEN`, `STRIP`, `BANNER` di `src/services/newsGen.js`).

## 8. Deployment 24/7
Butuh server yang selalu menyala (VPS Linux, mis. Ubuntu 22.04/24.04, RAM ≥ 512 MB).

**Opsi A — PM2**
```bash
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash - && sudo apt install -y nodejs build-essential python3
npm install && sudo npm i -g pm2
pm2 start ecosystem.config.js
pm2 save && pm2 startup        # jalankan perintah sudo yang ditampilkan
pm2 logs nattabot
```
**Opsi B — Docker**
```bash
docker compose up -d --build
docker compose logs -f
```
**Opsi C — systemd:** lihat `nattabot.service`.

Fitur ketahanan: auto-restart (PM2/Docker/systemd), tangkap crash tak terduga di log, reconnect voice otomatis, **backup DB harian** ke `backups/` (simpan 7 terakhir, atur `BACKUP_KEEP`), heartbeat opsional ke UptimeRobot/BetterStack (`UPTIME_PING_URL`).

## 9. Keamanan
- Token hanya di `.env` (sudah ada di `.gitignore`). Bila bocor: **Reset Token** di Developer Portal.
- Perintah admin dicek dua lapis: izin Discord (Administrator) + pengecekan di kode (pemilik bot atau administrator). `/maintenance` khusus `OWNER_ID`.
- Batasi akses SSH VPS (kunci SSH, firewall `ufw`).

## 10. Daftar perintah
**General:** `/help /ping /botinfo /profile /serverinfo`
**Economy:** `/balance /daily /weekly /transfer /leaderboard /history`
**Games:** `/slot /freespin /slotinfo /slotleaderboard`
**Voice:** `/voice /voice-status /voice-reconnect`
**Admin:** `/setvoice /setwelcome /setleave /setlog /maintenance`
**News:** `/news /newshelp /newstemplate` + reply-mention

## 11. Troubleshooting
- *Slash command tidak muncul:* isi `GUILD_ID`, restart, atau tunggu propagasi global.
- *Bot tidak masuk voice:* cek izin Connect/View, jalankan `/voice-status`, lihat `logs/`.
- *Welcome tidak muncul:* aktifkan Server Members Intent & jalankan `/setwelcome`.
- *Mention berita tidak merespons:* aktifkan Message Content Intent; pesan harus diawali mention bot dan merupakan reply.
- *Error `better-sqlite3`/canvas saat install:* `sudo apt install build-essential python3` lalu `npm install` ulang.
- *Voice error enkripsi:* pastikan dependensi `@snazzah/davey` & `libsodium-wrappers` ter-install, dan `@discordjs/voice` versi terbaru.

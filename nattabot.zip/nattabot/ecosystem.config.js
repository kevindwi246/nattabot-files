module.exports = {
  apps: [{
    name: 'nattabot',
    script: 'src/index.js',
    autorestart: true,
    max_restarts: 50,
    min_uptime: '20s',
    restart_delay: 5000,
    max_memory_restart: '400M',
    env: { NODE_ENV: 'production', TZ: 'Asia/Jakarta' },
  }],
};

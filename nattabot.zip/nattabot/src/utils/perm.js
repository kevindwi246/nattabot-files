const { PermissionFlagsBits } = require('discord.js');
const cfg = require('../config');

const isOwner = (userId) => userId === cfg.ownerId;
function isAdmin(interaction) {
  if (isOwner(interaction.user.id)) return true;
  return !!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator);
}
module.exports = { isOwner, isAdmin };

const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');
const cfg = require('./config');
const log = require('./logger');

fs.mkdirSync(path.dirname(cfg.dbPath), { recursive: true });
const db = new Database(cfg.dbPath);
db.pragma('journal_mode = WAL');
db.pragma('synchronous = NORMAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  user_id TEXT PRIMARY KEY,
  balance INTEGER NOT NULL DEFAULT ${cfg.economy.startBalance} CHECK (balance >= 0),
  total_earned INTEGER NOT NULL DEFAULT 0,
  total_spent INTEGER NOT NULL DEFAULT 0,
  last_daily INTEGER NOT NULL DEFAULT 0,
  last_weekly INTEGER NOT NULL DEFAULT 0,
  streak INTEGER NOT NULL DEFAULT 0,
  last_active_reward INTEGER NOT NULL DEFAULT 0,
  active_day TEXT NOT NULL DEFAULT '',
  active_count INTEGER NOT NULL DEFAULT 0,
  free_spins INTEGER NOT NULL DEFAULT 0,
  last_freespin INTEGER NOT NULL DEFAULT 0,
  lucky_day TEXT NOT NULL DEFAULT '',
  last_transfer INTEGER NOT NULL DEFAULT 0,
  transfer_day TEXT NOT NULL DEFAULT '',
  transfer_sum INTEGER NOT NULL DEFAULT 0,
  news_template TEXT NOT NULL DEFAULT 'classic',
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  type TEXT NOT NULL,
  amount INTEGER NOT NULL,
  balance_after INTEGER NOT NULL,
  note TEXT,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tx_user ON transactions(user_id, id DESC);
CREATE TABLE IF NOT EXISTS slot_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  bet INTEGER NOT NULL,
  reels TEXT NOT NULL,
  payout INTEGER NOT NULL,
  free INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_slot_user ON slot_history(user_id, id DESC);
CREATE TABLE IF NOT EXISTS slot_stats (
  user_id TEXT PRIMARY KEY,
  spins INTEGER NOT NULL DEFAULT 0,
  wins INTEGER NOT NULL DEFAULT 0,
  losses INTEGER NOT NULL DEFAULT 0,
  total_bet INTEGER NOT NULL DEFAULT 0,
  total_won INTEGER NOT NULL DEFAULT 0,
  biggest_win INTEGER NOT NULL DEFAULT 0,
  jackpots INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS guild_settings (
  guild_id TEXT PRIMARY KEY,
  voice_channel_id TEXT,
  voice_enabled INTEGER NOT NULL DEFAULT 0,
  welcome_channel_id TEXT,
  leave_channel_id TEXT,
  log_channel_id TEXT
);
CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS feature_usage (
  feature TEXT PRIMARY KEY,
  count INTEGER NOT NULL DEFAULT 0,
  last_used INTEGER NOT NULL DEFAULT 0
);
`);

const q = {
  getKv: db.prepare('SELECT value FROM kv WHERE key = ?'),
  setKv: db.prepare('INSERT INTO kv(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value'),
  getGuild: db.prepare('SELECT * FROM guild_settings WHERE guild_id = ?'),
  ensureGuild: db.prepare('INSERT OR IGNORE INTO guild_settings(guild_id) VALUES(?)'),
  usage: db.prepare(`INSERT INTO feature_usage(feature,count,last_used) VALUES(?,1,?)
    ON CONFLICT(feature) DO UPDATE SET count=count+1, last_used=excluded.last_used`),
};

const ALLOWED_GUILD_COLS = new Set(['voice_channel_id', 'voice_enabled', 'welcome_channel_id', 'leave_channel_id', 'log_channel_id']);

module.exports = {
  db,
  getKv: (k, def = null) => q.getKv.get(k)?.value ?? def,
  setKv: (k, v) => q.setKv.run(k, String(v)),
  getGuild(id) { q.ensureGuild.run(id); return q.getGuild.get(id); },
  setGuild(id, col, val) {
    if (!ALLOWED_GUILD_COLS.has(col)) throw new Error('kolom tidak valid');
    q.ensureGuild.run(id);
    db.prepare(`UPDATE guild_settings SET ${col} = ? WHERE guild_id = ?`).run(val, id);
  },
  allGuildSettings: () => db.prepare('SELECT * FROM guild_settings').all(),
  trackUsage: (feature) => { try { q.usage.run(feature, Date.now()); } catch (e) { log.warn('trackUsage', e.message); } },
};

const fs = require('fs');
const path = require('path');

function loadCommands() {
  const map = new Map();
  const dir = path.join(__dirname, 'commands');
  for (const f of fs.readdirSync(dir).filter((x) => x.endsWith('.js'))) {
    for (const cmd of require(path.join(dir, f))) map.set(cmd.data.name, cmd);
  }
  return map;
}
module.exports = { loadCommands };

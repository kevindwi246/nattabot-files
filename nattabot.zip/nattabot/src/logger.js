const fs = require('fs');
const path = require('path');
const dir = path.join(process.cwd(), 'logs');
fs.mkdirSync(dir, { recursive: true });

function stamp() {
  return new Date().toLocaleString('sv-SE', { timeZone: process.env.TZ || 'Asia/Jakarta' });
}
function write(level, args) {
  const line = `[${stamp()}] [${level}] ${args.map((a) => (a instanceof Error ? a.stack : typeof a === 'string' ? a : JSON.stringify(a))).join(' ')}`;
  (level === 'ERROR' ? console.error : console.log)(line);
  const file = path.join(dir, `${new Date().toISOString().slice(0, 10)}.log`);
  fs.appendFile(file, line + '\n', () => {});
}
module.exports = {
  info: (...a) => write('INFO', a),
  warn: (...a) => write('WARN', a),
  error: (...a) => write('ERROR', a),
};

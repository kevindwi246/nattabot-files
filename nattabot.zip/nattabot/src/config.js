require('dotenv').config();

const required = ['DISCORD_TOKEN', 'CLIENT_ID', 'OWNER_ID'];
const missing = required.filter((k) => !process.env[k]);
if (missing.length) {
  console.error(`[FATAL] Variabel .env belum diisi: ${missing.join(', ')}`);
  process.exit(1);
}

module.exports = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,
  ownerId: process.env.OWNER_ID,
  guildId: process.env.GUILD_ID || null,
  pingUrl: process.env.UPTIME_PING_URL || null,
  dbPath: process.env.DB_PATH || './data/nattabot.db',
  backupDir: process.env.BACKUP_DIR || './backups',
  backupKeep: parseInt(process.env.BACKUP_KEEP || '7', 10),

  // Tema visual NattaBot: violet–cyan futuristik
  colors: { primary: 0x7c5cff, accent: 0x00e5ff, success: 0x2ee6a6, danger: 0xff4d6d, warn: 0xffc24d, dark: 0x0b0d1a },

  economy: {
    startBalance: 10_000,
    dailyBase: 5_000,
    dailyStreakStep: 500,
    dailyStreakMax: 7,
    weeklyReward: 30_000,
    surpriseChance: 0.1,
    surpriseMin: 2_500,
    surpriseMax: 10_000,
    activeReward: 25,
    activeCooldownMs: 60_000,
    activeDailyCap: 40,
    transferMin: 100,
    transferMax: 100_000,
    transferDailyLimit: 500_000,
    transferCooldownMs: 10_000,
  },
  slot: { minBet: 100, maxBet: 50_000, cooldownMs: 4_000, freeSpinBet: 1_000, freeSpinsPerClaim: 3, jackpotSeed: 100_000, jackpotContribution: 0.02, pairMultiplier: 2, luckyBonus: 0.25 },
};

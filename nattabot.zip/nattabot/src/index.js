const { Client, GatewayIntentBits, Partials, Events, AttachmentBuilder, ActivityType, MessageFlags } = require('discord.js');
const fs = require('fs');
const path = require('path');
const cfg = require('./config');
const log = require('./logger');
const dbm = require('./db');
const { loadCommands } = require('./loader');
const { deploy } = require('./deploy-commands');
const VoiceKeeper = require('./services/voiceKeeper');
const eco = require('./services/economy');
const { makeCard } = require('./services/cardGen');
const { err, embed } = require('./theme');
const { isAdmin, isOwner } = require('./utils/perm');
const news = require('./commands/news');
const { helpEmbed, helpMenu } = require('./commands/general');

process.on('unhandledRejection', (e) => log.error('unhandledRejection', e));
process.on('uncaughtException', (e) => { log.error('uncaughtException', e); });

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,       // privileged: Welcome/Leave
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,     // privileged: Natta News via mention
  ],
  partials: [Partials.GuildMember],
  presence: { activities: [{ name: 'Natta • 24/7', type: ActivityType.Listening }] },
});

const commands = loadCommands();
const keeper = new VoiceKeeper(client);
client.keeper = keeper;
const startedAt = Date.now();

client.once(Events.ClientReady, async (c) => {
  log.info(`NattaBot online sebagai ${c.user.tag} di ${c.guilds.cache.size} server`);
  try { log.info(`${await deploy()} slash command diperbarui`); } catch (e) { log.error('Deploy command gagal', e); }
  await keeper.start();
  startBackups();
  startHeartbeat();
});

client.on(Events.InteractionCreate, async (i) => {
  try {
    if (i.isStringSelectMenu() && i.customId === 'help:menu') {
      return void i.update({ embeds: [helpEmbed(i.values[0])], components: [helpMenu()] });
    }
    if (!i.isChatInputCommand()) return;
    const cmd = commands.get(i.commandName);
    if (!cmd) return;

    if (cmd.ownerOnly && !isOwner(i.user.id)) return void i.reply({ embeds: [err('Akses ditolak', 'Perintah ini hanya untuk pemilik bot.')], flags: MessageFlags.Ephemeral });
    if (cmd.adminOnly && !isAdmin(i)) return void i.reply({ embeds: [err('Akses ditolak', 'Perintah ini hanya untuk administrator.')], flags: MessageFlags.Ephemeral });
    if (dbm.getKv('maintenance') === '1' && !isAdmin(i)) return void i.reply({ embeds: [embed('warn').setTitle('🛠 Maintenance').setDescription('NattaBot sedang maintenance. Coba lagi sebentar lagi.')], flags: MessageFlags.Ephemeral });
    if (cmd.data.name === 'serverinfo' && !i.guild) return;

    dbm.trackUsage(cmd.data.name);
    await cmd.execute(i, { keeper });
  } catch (e) {
    log.error(`Command /${i.commandName} error`, e);
    const payload = { embeds: [err('Terjadi kesalahan', 'Maaf, ada error. Coba lagi sebentar.')], flags: MessageFlags.Ephemeral };
    try { if (i.deferred || i.replied) await i.followUp(payload); else await i.reply(payload); } catch {}
  }
});

// ===== Join / Leave =====
async function announce(member, mode) {
  try {
    const s = dbm.getGuild(member.guild.id);
    const chId = mode === 'join' ? s.welcome_channel_id : s.leave_channel_id;
    if (!chId) return;
    const ch = await member.guild.channels.fetch(chId).catch(() => null);
    if (!ch?.isTextBased()) return;
    const user = member.user;
    const png = await makeCard({
      mode, avatarUrl: user.displayAvatarURL({ extension: 'png', size: 512, forceStatic: true }),
      displayName: member.displayName ?? user.globalName ?? user.username, username: user.username,
      memberNo: mode === 'join' ? member.guild.memberCount : null, guildName: member.guild.name,
    });
    const file = new AttachmentBuilder(png, { name: `${mode}.png` });
    await ch.send({
      content: mode === 'join' ? `Selamat datang, ${member}! ✦` : `**${user.username}** telah meninggalkan server.`,
      files: [file], allowedMentions: { users: mode === 'join' ? [user.id] : [] },
    });
  } catch (e) { log.error(`announce ${mode} gagal`, e); }
}
client.on(Events.GuildMemberAdd, (m) => announce(m, 'join'));
client.on(Events.GuildMemberRemove, (m) => announce(m, 'leave'));

// ===== Voice: bot dipindah/ditendang =====
client.on(Events.VoiceStateUpdate, (o, n) => { if (n.id === client.user.id) keeper.onBotVoiceUpdate(o, n); });

// ===== Pesan: Natta News (reply + mention) & bonus aktif =====
client.on(Events.MessageCreate, async (msg) => {
  try {
    if (msg.author.bot || !msg.guild) return;
    const mentioned = msg.mentions.has(client.user, { ignoreEveryone: true, ignoreRoles: true }) && new RegExp(`^<@!?${client.user.id}>`).test(msg.content.trim());
    if (mentioned) {
      if (dbm.getKv('maintenance') === '1' && msg.author.id !== cfg.ownerId) return;
      if (!msg.reference?.messageId) {
        return void msg.reply({ embeds: [err('Reply dulu ya', 'Reply pesan seseorang, lalu mention aku dengan headline.\n\n' + news.HELP_TEXT)], allowedMentions: { repliedUser: false } });
      }
      const text = news.clean(msg.content);
      if (!text || text.length > news.MAX_LEN) {
        return void msg.reply({ embeds: [err('Format kurang pas', (text ? `Maksimal ${news.MAX_LEN} karakter.\n\n` : '') + news.HELP_TEXT)], allowedMentions: { repliedUser: false } });
      }
      const target = await msg.fetchReference().then((m) => m.author).catch(() => null);
      if (!target) return void msg.reply({ embeds: [err('Pesan tidak ditemukan', 'Pesan yang kamu reply sudah dihapus.')], allowedMentions: { repliedUser: false } });
      dbm.trackUsage('news');
      await msg.channel.sendTyping().catch(() => {});
      return void news.buildAndSend({ text, targetUser: target, requesterId: msg.author.id, send: (p) => msg.channel.send({ ...p, reply: { messageReference: msg.id }, allowedMentions: { repliedUser: false } }) });
    }
    // bonus aktivitas (anti-spam di dalam economy.activeReward)
    if (msg.content.length >= 5 && dbm.getKv('maintenance') !== '1') {
      if (eco.activeReward(msg.author.id)) msg.react('🪙').catch(() => {});
    }
  } catch (e) { log.error('messageCreate error', e); }
});

// ===== Backup DB harian & heartbeat =====
function startBackups() {
  fs.mkdirSync(cfg.backupDir, { recursive: true });
  const run = async () => {
    try {
      const file = path.join(cfg.backupDir, `nattabot-${new Date().toISOString().slice(0, 10)}.db`);
      await dbm.db.backup(file);
      const all = fs.readdirSync(cfg.backupDir).filter((f) => f.endsWith('.db')).sort();
      for (const old of all.slice(0, Math.max(0, all.length - cfg.backupKeep))) fs.unlinkSync(path.join(cfg.backupDir, old));
      log.info('Backup database OK:', file);
    } catch (e) { log.error('Backup gagal', e); }
  };
  run(); setInterval(run, 24 * 3600e3);
}
function startHeartbeat() {
  if (!cfg.pingUrl) return;
  setInterval(() => { if (client.ws.status === 0) fetch(cfg.pingUrl).catch((e) => log.warn('heartbeat gagal', e.message)); }, 60_000);
}

client.on(Events.Error, (e) => log.error('client error', e));
client.on(Events.ShardDisconnect, (ev, id) => log.warn(`Shard ${id} disconnect (${ev.code})`));
client.on(Events.ShardReconnecting, (id) => log.warn(`Shard ${id} reconnecting`));

for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { log.info(`${sig} diterima, menutup…`); try { dbm.db.close(); } catch {} client.destroy(); process.exit(0); });

client.login(cfg.token).catch((e) => { log.error('Login gagal — cek DISCORD_TOKEN', e); process.exit(1); });

const { SlashCommandBuilder, ChannelType, PermissionFlagsBits } = require('discord.js');
const { ok, err, embed } = require('../theme');
const { isOwner } = require('../utils/perm');
const dbm = require('../db');

const A = PermissionFlagsBits.Administrator;
const textTypes = [ChannelType.GuildText, ChannelType.GuildAnnouncement];
const chanOpt = (o, types, name = 'channel') => o.setName(name).setDescription('Pilih channel').addChannelTypes(...types).setRequired(true);

module.exports = [
  {
    data: new SlashCommandBuilder().setName('setvoice').setDescription('Atur voice channel tujuan Voice Keeper').setDMPermission(false).setDefaultMemberPermissions(A)
      .addChannelOption((o) => chanOpt(o, [ChannelType.GuildVoice, ChannelType.GuildStageVoice])),
    adminOnly: true,
    async execute(i, { keeper }) {
      const ch = i.options.getChannel('channel');
      dbm.setGuild(i.guild.id, 'voice_channel_id', ch.id);
      const s = dbm.getGuild(i.guild.id);
      if (s.voice_enabled) { await i.deferReply({ ephemeral: true }); await keeper.enable(i.guild.id, ch.id); return i.editReply({ embeds: [ok('Voice channel diperbarui', `Bot pindah ke ${ch}.`)] }); }
      await i.reply({ ephemeral: true, embeds: [ok('Voice channel diatur', `${ch}\nAktifkan dengan \`/voice on\`.`)] });
    },
  },
  {
    data: new SlashCommandBuilder().setName('setwelcome').setDescription('Atur channel pengumuman Member Join').setDMPermission(false).setDefaultMemberPermissions(A)
      .addChannelOption((o) => chanOpt(o, textTypes)),
    adminOnly: true,
    async execute(i) {
      const ch = i.options.getChannel('channel'); dbm.setGuild(i.guild.id, 'welcome_channel_id', ch.id);
      await i.reply({ ephemeral: true, embeds: [ok('Channel Welcome diatur', `${ch}`)] });
    },
  },
  {
    data: new SlashCommandBuilder().setName('setleave').setDescription('Atur channel pengumuman Member Leave').setDMPermission(false).setDefaultMemberPermissions(A)
      .addChannelOption((o) => chanOpt(o, textTypes)),
    adminOnly: true,
    async execute(i) {
      const ch = i.options.getChannel('channel'); dbm.setGuild(i.guild.id, 'leave_channel_id', ch.id);
      await i.reply({ ephemeral: true, embeds: [ok('Channel Leave diatur', `${ch}`)] });
    },
  },
  {
    data: new SlashCommandBuilder().setName('setlog').setDescription('Atur channel log (voice masuk/keluar/gangguan)').setDMPermission(false).setDefaultMemberPermissions(A)
      .addChannelOption((o) => chanOpt(o, textTypes)),
    adminOnly: true,
    async execute(i) {
      const ch = i.options.getChannel('channel'); dbm.setGuild(i.guild.id, 'log_channel_id', ch.id);
      await i.reply({ ephemeral: true, embeds: [ok('Channel Log diatur', `${ch}`)] });
    },
  },
  {
    data: new SlashCommandBuilder().setName('maintenance').setDescription('Mode maintenance (khusus pemilik bot)').setDefaultMemberPermissions(A)
      .addStringOption((o) => o.setName('mode').setDescription('on / off').setRequired(true).addChoices({ name: 'on', value: 'on' }, { name: 'off', value: 'off' })),
    ownerOnly: true,
    async execute(i) {
      const on = i.options.getString('mode') === 'on';
      dbm.setKv('maintenance', on ? '1' : '0');
      await i.reply({ ephemeral: true, embeds: [on ? embed('warn').setTitle('🛠 Maintenance ON').setDescription('Perintah non-admin dinonaktifkan sementara.') : ok('Maintenance OFF', 'Bot kembali normal.')] });
    },
  },
];

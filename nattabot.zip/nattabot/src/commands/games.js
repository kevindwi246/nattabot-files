const { SlashCommandBuilder } = require('discord.js');
const { embed, err, nc, VIRTUAL_NOTE, relTime } = require('../theme');
const slot = require('../services/slot');
const cfg = require('../config');

const S = cfg.slot;
const lastSpin = new Map(); const busy = new Set();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const rnd = () => slot.pick().emoji;
const row = (a, b, c) => `┃ ${a} ┃ ${b} ┃ ${c} ┃`;
const pct = (x) => `${(x * 100).toFixed(2)}%`;

async function play(i, bet, free) {
  const uid = i.user.id;
  if (busy.has(uid)) return i.reply({ content: 'Putaran sebelumnya masih berjalan…', ephemeral: true });
  const wait = (lastSpin.get(uid) ?? 0) + S.cooldownMs - Date.now();
  if (wait > 0) return i.reply({ embeds: [err('Cooldown', `Tunggu ${(wait / 1000).toFixed(1)} detik lagi.`)], ephemeral: true });
  busy.add(uid);
  try {
    let res;
    try { res = slot.spin(uid, bet, free); } catch (e) {
      if (e.message === 'INSUFFICIENT') return i.reply({ embeds: [err('Saldo tidak cukup', 'Klaim `/daily` atau `/weekly` dulu, atau pakai `/freespin`.')], ephemeral: true });
      if (e.message === 'NO_FREE_SPIN') return i.reply({ embeds: [err('Free spin habis', 'Klaim lagi dengan `/freespin`.')], ephemeral: true });
      throw e;
    }
    lastSpin.set(uid, Date.now());
    const title = free ? '🎁 NATTA SLOT • FREE SPIN' : '🎰 NATTA SLOT';
    const frame = (a, b, c, extra = 'Memutar…') => embed('accent').setTitle(title).setDescription(`\`\`\`\n┏━━━┳━━━┳━━━┓\n${row(a, b, c)}\n┗━━━┻━━━┻━━━┛\`\`\`${extra}`);
    await i.reply({ embeds: [frame('🌀', '🌀', '🌀')] });
    await sleep(700); await i.editReply({ embeds: [frame(res.reels[0].emoji, '🌀', '🌀')] });
    await sleep(700); await i.editReply({ embeds: [frame(res.reels[0].emoji, res.reels[1].emoji, '🌀')] });
    await sleep(700);
    const won = res.payout > 0;
    const color = res.jackpotWon || res.mult >= 30 ? 'warn' : won ? 'success' : 'danger';
    let desc = `\`\`\`\n┏━━━┳━━━┳━━━┓\n${row(...res.reels.map((r) => r.emoji))}\n┗━━━┻━━━┻━━━┛\`\`\``;
    desc += won ? `✨ **${res.label}**\nTaruhan: ${free ? 'GRATIS' : nc(res.bet)}\nHadiah: **+${nc(res.payout)}**` : `💨 **Belum beruntung.** Taruhan ${free ? 'gratis' : nc(res.bet)}`;
    if (res.luckyBonus) desc += `\n🍀 Bonus keberuntungan harian: +${nc(res.luckyBonus)}`;
    if (res.jackpotWon) desc += `\n\n🚨 **JACKPOT PROGRESIF!** +${nc(res.jackpotWon)}`;
    desc += `\n\nSaldo: **${nc(res.balance)}**  •  Jackpot progresif: ${nc(slot.getPool())}`;
    await i.editReply({ embeds: [embed(color).setTitle(res.mult >= 30 ? `🚨 ${title} • JACKPOT!` : title).setDescription(desc)] });
    if (res.mult >= 30) await i.followUp(`🎉 **${i.user} memenangkan ${res.label}!** (+${nc(res.payout)})`);
  } finally { busy.delete(uid); }
}

module.exports = [
  {
    data: new SlashCommandBuilder().setName('slot').setDescription('Main Natta Slot dengan Natta Coins')
      .addIntegerOption((o) => o.setName('taruhan').setDescription(`Taruhan ${S.minBet}–${S.maxBet} NC`).setRequired(true).setMinValue(S.minBet).setMaxValue(S.maxBet)),
    execute: (i) => play(i, i.options.getInteger('taruhan'), false),
  },
  {
    data: new SlashCommandBuilder().setName('freespin').setDescription(`Klaim ${S.freeSpinsPerClaim} free spin harian & pakai satu`),
    async execute(i) {
      const claim = slot.claimFreeSpins(i.user.id);
      const u = require('../services/economy').getUser(i.user.id);
      if (u.free_spins < 1) return i.reply({ embeds: [err('Free spin habis', `Klaim berikutnya ${relTime(Date.now() + claim.wait)}.`)], ephemeral: true });
      if (claim.ok) await i.channel?.send({ content: `🎁 ${i.user} mengklaim **${S.freeSpinsPerClaim} free spin**!` }).catch(() => {});
      return play(i, S.freeSpinBet, true);
    },
  },
  {
    data: new SlashCommandBuilder().setName('slotinfo').setDescription('Tabel hadiah, peluang & statistik slot kamu'),
    async execute(i) {
      const st = slot.stats(); const me = slot.userStats(i.user.id);
      const recent = slot.recent(i.user.id, 5).map((r) => `${r.reels} → ${r.payout > 0 ? '+' + nc(r.payout) : 'zonk'}${r.free ? ' (free)' : ''}`).join('\n') || '—';
      const table = slot.SYMBOLS.map((s) => `${s.emoji} 3× ${s.name} → **${s.mult}×** (${pct((s.weight / slot.SYMBOLS.reduce((a, x) => a + x.weight, 0)) ** 3)}) — ${s.tier}`).join('\n');
      await i.reply({ ephemeral: true, embeds: [embed().setTitle('🎰 NATTA SLOT — INFO').setDescription(
        `${table}\n\n**Sepasang simbol sama → ${S.pairMultiplier}×**\n\n` +
        `**Peluang menang tiap putaran:** ${pct(st.pWin)} (triple ${pct(st.pTriple)} + sepasang ${pct(st.pPair)})\n` +
        `**Pengembalian teoretis (RTP):** ${pct(st.rtp)} — sama untuk semua pemain, tanpa penyesuaian tersembunyi.\n` +
        `🍀 Kemenangan pertama setiap hari: +${S.luckyBonus * 100}% bonus\n🚨 Jackpot progresif: **${nc(slot.getPool())}** (diraih lewat 3× Lucky Seven; ${S.jackpotContribution * 100}% taruhan masuk pool)\n` +
        `Taruhan ${nc(S.minBet)}–${nc(S.maxBet)} • cooldown ${S.cooldownMs / 1000} dtk\n\n` +
        `**Statistik kamu:** ${me.spins} putaran • ${me.wins} menang • ${me.losses} kalah • total menang ${nc(me.total_won)} • terbesar ${nc(me.biggest_win)}\n**5 putaran terakhir:**\n${recent}\n\n${VIRTUAL_NOTE}`)] });
    },
  },
  {
    data: new SlashCommandBuilder().setName('slotleaderboard').setDescription('Peringkat pemenang slot'),
    async execute(i) {
      await i.deferReply(); const medals = ['🥇', '🥈', '🥉'];
      const lines = await Promise.all(slot.leaderboard(10).map(async (r, n) => {
        const u = await i.client.users.fetch(r.user_id).catch(() => null);
        return `${medals[n] ?? `\`${String(n + 1).padStart(2, '0')}\``} **${u?.username ?? r.user_id}** — ${nc(r.total_won)} • ${r.spins}× main • 🏅 ${nc(r.biggest_win)}`;
      }));
      await i.editReply({ embeds: [embed().setTitle('🎰 SLOT LEADERBOARD').setDescription(lines.join('\n') || 'Belum ada yang bermain.')] });
    },
  },
];

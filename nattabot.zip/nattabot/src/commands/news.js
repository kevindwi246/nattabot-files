const { SlashCommandBuilder, AttachmentBuilder } = require('discord.js');
const { embed, err, ok } = require('../theme');
const { makeNews, TEMPLATES } = require('../services/newsGen');
const { db } = require('../db');
const eco = require('../services/economy');

const MAX_LEN = 120;
const cooldown = new Map();
const COOLDOWN_MS = 5_000;

const clean = (t) => t.replace(/<@!?\d+>/g, '').replace(/^[\s\-–—]+|[\s\-–—]+$/g, '').replace(/\s+/g, ' ').trim();

const HELP_TEXT =
  '**Cara pakai (reply + mention):**\n1. **Reply** pesan orang yang fotonya mau dijadikan berita\n2. Ketik mention bot lalu headline di antara tanda `-`:\n' +
  '`@NattaBot - Seorang wanita pingsan saat berkendara -`\n\n' +
  `• Foto profil orang yang di-reply otomatis masuk ke layar studio\n• Maksimal ${MAX_LEN} karakter\n• Template pribadi: \`/newstemplate\`\n• Alternatif: \`/news headline:… user:@seseorang\``;

// Dipakai juga oleh handler messageCreate di index.js
async function buildAndSend({ text, targetUser, requesterId, send }) {
  const wait = (cooldown.get(requesterId) ?? 0) + COOLDOWN_MS - Date.now();
  if (wait > 0) return send({ embeds: [err('Sabar dulu', `Tunggu ${Math.ceil(wait / 1000)} detik.`)] });
  cooldown.set(requesterId, Date.now());
  const tpl = eco.getUser(requesterId).news_template;
  const png = await makeNews({ text, avatarUrl: targetUser.displayAvatarURL({ extension: 'png', size: 512, forceStatic: true }), template: tpl });
  return send({ files: [new AttachmentBuilder(png, { name: 'natta-news.png' })] });
}

module.exports = [
  {
    data: new SlashCommandBuilder().setName('news').setDescription('Buat gambar berita dari headline')
      .addStringOption((o) => o.setName('headline').setDescription('Isi berita').setRequired(true).setMaxLength(MAX_LEN))
      .addUserOption((o) => o.setName('user').setDescription('Foto profil siapa (default: kamu)')),
    async execute(i) {
      const text = clean(i.options.getString('headline'));
      if (!text) return i.reply({ embeds: [err('Headline kosong', HELP_TEXT)], ephemeral: true });
      await i.deferReply();
      const target = i.options.getUser('user') ?? i.user;
      await buildAndSend({ text, targetUser: target, requesterId: i.user.id, send: (p) => i.editReply(p) });
    },
  },
  {
    data: new SlashCommandBuilder().setName('newshelp').setDescription('Cara membuat gambar berita'),
    async execute(i) { await i.reply({ ephemeral: true, embeds: [embed().setTitle('📰 NATTA NEWS').setDescription(HELP_TEXT)] }); },
  },
  {
    data: new SlashCommandBuilder().setName('newstemplate').setDescription('Pilih template berita favoritmu')
      .addStringOption((o) => o.setName('template').setDescription('Template').addChoices(...Object.entries(TEMPLATES).map(([value, t]) => ({ name: t.name, value })))),
    async execute(i) {
      const pick = i.options.getString('template');
      if (!pick) {
        const cur = eco.getUser(i.user.id).news_template;
        return i.reply({ ephemeral: true, embeds: [embed().setTitle('🎨 Template Natta News').setDescription(
          Object.entries(TEMPLATES).map(([k, t]) => `${k === cur ? '✅' : '▫️'} **${t.name}** (\`${k}\`) — ${t.desc}`).join('\n') + '\n\nGanti: `/newstemplate template:<pilihan>`')] });
      }
      eco.getUser(i.user.id);
      db.prepare('UPDATE users SET news_template = ? WHERE user_id = ?').run(pick, i.user.id);
      await i.reply({ ephemeral: true, embeds: [ok('Template diganti', `**${TEMPLATES[pick].name}**`)] });
    },
  },
];
module.exports.buildAndSend = buildAndSend; module.exports.clean = clean; module.exports.HELP_TEXT = HELP_TEXT; module.exports.MAX_LEN = MAX_LEN;

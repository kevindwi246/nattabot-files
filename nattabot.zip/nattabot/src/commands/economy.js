const { SlashCommandBuilder } = require('discord.js');
const { embed, ok, err, nc, VIRTUAL_NOTE, relTime, fmtDuration } = require('../theme');
const eco = require('../services/economy');
const cfg = require('../config');

const ts = (ms) => relTime(Date.now() + ms);

module.exports = [
  {
    data: new SlashCommandBuilder().setName('balance').setDescription('Lihat dompet Natta Wallet')
      .addUserOption((o) => o.setName('user').setDescription('Anggota lain (opsional)')),
    async execute(i) {
      const user = i.options.getUser('user') ?? i.user;
      if (user.bot) return i.reply({ content: 'Bot tidak punya dompet.', ephemeral: true });
      const u = eco.getUser(user.id); const now = Date.now();
      const d = u.last_daily + 24 * 3600e3 - now, w = u.last_weekly + 7 * 24 * 3600e3 - now;
      await i.reply({ embeds: [embed().setTitle('◈ NATTA WALLET').setThumbnail(user.displayAvatarURL({ size: 256 }))
        .setDescription(`**Username:** <@${user.id}>\n**Balance:** \`${nc(u.balance)}\`\n**Peringkat:** #${eco.rank(user.id)}\n\n` +
          `**Daily Reward:** ${d <= 0 ? '🟢 Available' : `🔴 Claimed • ${ts(d)}`}\n**Weekly Reward:** ${w <= 0 ? '🟢 Available' : `🔴 Claimed • ${ts(w)}`}\n**Streak:** 🔥 ${u.streak} hari\n\n${VIRTUAL_NOTE}`)] });
    },
  },
  {
    data: new SlashCommandBuilder().setName('daily').setDescription('Klaim hadiah harian + bonus streak'),
    async execute(i) {
      const r = eco.claimDaily(i.user.id);
      if (!r.ok) return i.reply({ embeds: [err('Belum waktunya', `Daily berikutnya ${ts(r.wait)}.`)], ephemeral: true });
      await i.reply({ embeds: [ok('Daily Reward Diterima', `+**${nc(r.total)}**\n\n• Dasar: ${nc(r.base)}\n• Bonus login streak (${r.streak} hari): ${nc(r.bonus)}\n` +
        (r.surprise ? `• 🎁 **Hadiah kejutan:** ${nc(r.surprise)}\n` : '') + `\nSaldo sekarang: **${nc(r.balance)}**`)] });
    },
  },
  {
    data: new SlashCommandBuilder().setName('weekly').setDescription('Klaim hadiah mingguan'),
    async execute(i) {
      const r = eco.claimWeekly(i.user.id);
      if (!r.ok) return i.reply({ embeds: [err('Belum waktunya', `Weekly berikutnya ${ts(r.wait)}.`)], ephemeral: true });
      await i.reply({ embeds: [ok('Weekly Reward Diterima', `+**${nc(r.total)}**\nSaldo sekarang: **${nc(r.balance)}**`)] });
    },
  },
  {
    data: new SlashCommandBuilder().setName('transfer').setDescription('Kirim Natta Coins ke anggota')
      .addUserOption((o) => o.setName('user').setDescription('Penerima').setRequired(true))
      .addIntegerOption((o) => o.setName('jumlah').setDescription('Jumlah NC').setRequired(true).setMinValue(cfg.economy.transferMin).setMaxValue(cfg.economy.transferMax)),
    async execute(i) {
      const to = i.options.getUser('user'); const amount = i.options.getInteger('jumlah');
      if (to.bot) return i.reply({ embeds: [err('Gagal', 'Tidak bisa transfer ke bot.')], ephemeral: true });
      const r = eco.transfer(i.user.id, to.id, amount);
      if (!r.ok) return i.reply({ embeds: [err('Transfer gagal', r.reason)], ephemeral: true });
      await i.reply({ embeds: [ok('Transfer Berhasil', `<@${i.user.id}> ➜ <@${to.id}>\n**${nc(amount)}**\n\nSaldo kamu: **${nc(r.balance)}**`)] });
    },
  },
  {
    data: new SlashCommandBuilder().setName('leaderboard').setDescription('10 anggota terkaya'),
    async execute(i) {
      await i.deferReply();
      const rows = eco.top(10); const medals = ['🥇', '🥈', '🥉'];
      const lines = await Promise.all(rows.map(async (r, n) => {
        const u = await i.client.users.fetch(r.user_id).catch(() => null);
        return `${medals[n] ?? `\`${String(n + 1).padStart(2, '0')}\``} **${u?.username ?? r.user_id}** — ${nc(r.balance)}`;
      }));
      await i.editReply({ embeds: [embed().setTitle('👑 NATTA RICHEST').setDescription(lines.join('\n') || 'Belum ada data.')] });
    },
  },
  {
    data: new SlashCommandBuilder().setName('history').setDescription('Riwayat 10 transaksi terakhir'),
    async execute(i) {
      const rows = eco.history(i.user.id, 10);
      const L = { daily: 'Daily', weekly: 'Weekly', transfer_in: 'Transfer masuk', transfer_out: 'Transfer keluar', slot_bet: 'Taruhan slot', slot_win: 'Menang slot', slot_free_win: 'Menang free spin', active: 'Bonus aktif', admin: 'Admin' };
      const text = rows.map((r) => `${r.amount >= 0 ? '🟢 +' : '🔴 '}${r.amount.toLocaleString('id-ID')} • ${L[r.type] ?? r.type} • ${relTime(r.created_at)}`).join('\n');
      await i.reply({ ephemeral: true, embeds: [embed().setTitle('📜 Riwayat Transaksi').setDescription(text || 'Belum ada transaksi.')] });
    },
  },
];

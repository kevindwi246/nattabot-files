const { SlashCommandBuilder, ChannelType, PermissionFlagsBits } = require('discord.js');
const { embed, ok, err, relTime } = require('../theme');
const { isAdmin } = require('../utils/perm');
const dbm = require('../db');

module.exports = [
  {
    data: new SlashCommandBuilder().setName('voice').setDescription('Aktifkan / nonaktifkan Voice Keeper 24/7').setDMPermission(false)
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
      .addStringOption((o) => o.setName('mode').setDescription('on / off').setRequired(true).addChoices({ name: 'on — aktifkan', value: 'on' }, { name: 'off — nonaktifkan', value: 'off' })),
    adminOnly: true,
    async execute(i, { keeper }) {
      await i.deferReply({ ephemeral: true });
      if (i.options.getString('mode') === 'off') { keeper.disable(i.guild.id); return i.editReply({ embeds: [ok('Voice Keeper OFF', 'Bot keluar dari voice channel.')] }); }
      const s = dbm.getGuild(i.guild.id);
      if (!s.voice_channel_id) return i.editReply({ embeds: [err('Channel belum diatur', 'Jalankan `/setvoice` dulu.')] });
      const done = await keeper.enable(i.guild.id);
      await i.editReply({ embeds: [done ? ok('Voice Keeper ON', `Standby 24/7 di <#${s.voice_channel_id}>.`) : err('Belum tersambung', 'Cek izin bot. Bot akan terus mencoba otomatis; lihat `/voice-status`.')] });
    },
  },
  {
    data: new SlashCommandBuilder().setName('voice-status').setDescription('Status Voice Keeper').setDMPermission(false),
    async execute(i, { keeper }) {
      const s = keeper.status(i.guild.id);
      await i.reply({ ephemeral: true, embeds: [embed(s.connected ? 'success' : s.enabled ? 'warn' : 'danger').setTitle('🎧 VOICE KEEPER')
        .addFields(
          { name: 'Fitur', value: s.enabled ? '🟢 ON' : '⚫ OFF', inline: true },
          { name: 'Koneksi', value: s.connected ? '🟢 Terhubung' : `🔴 ${s.status}`, inline: true },
          { name: 'Channel', value: s.channelId ? `<#${s.channelId}>` : 'Belum diatur', inline: true },
          { name: 'Voice ping', value: s.ping != null ? `${s.ping} ms` : '—', inline: true },
          { name: 'Online sejak', value: s.since ? relTime(s.since) : '—', inline: true },
          { name: 'Reconnect (sesi ini)', value: String(s.reconnects), inline: true })] });
    },
  },
  {
    data: new SlashCommandBuilder().setName('voice-reconnect').setDescription('Paksa bot sambung ulang ke voice').setDMPermission(false)
      .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    adminOnly: true,
    async execute(i, { keeper }) {
      await i.deferReply({ ephemeral: true });
      const s = dbm.getGuild(i.guild.id);
      if (!s.voice_enabled) return i.editReply({ embeds: [err('Voice Keeper OFF', 'Aktifkan dengan `/voice on`.')] });
      require('@discordjs/voice').getVoiceConnection(i.guild.id)?.destroy();
      const done = await keeper.connect(i.guild.id, 'reconnect manual');
      await i.editReply({ embeds: [done ? ok('Tersambung kembali', `<#${s.voice_channel_id}>`) : err('Gagal', 'Akan dicoba lagi otomatis.')] });
    },
  },
];

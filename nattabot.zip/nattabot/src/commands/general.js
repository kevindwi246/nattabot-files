const { SlashCommandBuilder, ActionRowBuilder, StringSelectMenuBuilder, ChannelType, version: djsVersion } = require('discord.js');
const os = require('os');
const { embed, nc, fmtDuration, relTime } = require('../theme');
const eco = require('../services/economy');
const slot = require('../services/slot');

const HELP = {
  home: { label: 'Beranda', emoji: '🏠', text: 'Pilih kategori di menu bawah untuk melihat seluruh perintah NattaBot.\n\n**Voice Keeper 24/7 · Natta Coins · Natta Slot · Join/Leave · Natta News**' },
  general: { label: 'General', emoji: '✨', text: '`/help` `/ping` `/botinfo` `/profile` `/serverinfo`' },
  economy: { label: 'Economy', emoji: '🪙', text: '`/balance` saldo & status klaim\n`/daily` hadiah harian (+streak, kejutan)\n`/weekly` hadiah mingguan\n`/transfer` kirim NC ke anggota\n`/leaderboard` orang terkaya\n`/history` riwayat transaksi' },
  games: { label: 'Games', emoji: '🎰', text: '`/slot` putar slot\n`/freespin` klaim & pakai free spin harian\n`/slotinfo` tabel hadiah, peluang, jackpot\n`/slotleaderboard` peringkat slot' },
  voice: { label: 'Voice', emoji: '🎧', text: '`/voice` aktif/nonaktifkan Voice Keeper (admin)\n`/voice-status` status koneksi\n`/voice-reconnect` paksa sambung ulang (admin)' },
  news: { label: 'News', emoji: '📰', text: '**Reply** pesan seseorang lalu mention bot:\n`@NattaBot - Seorang wanita pingsan saat berkendara -`\n\n`/news` `/newshelp` `/newstemplate`' },
  admin: { label: 'Admin', emoji: '🛡️', text: '`/setvoice` `/setwelcome` `/setleave` `/setlog` `/maintenance`\n*Hanya pemilik bot / administrator.*' },
};
function helpEmbed(key) {
  const h = HELP[key];
  return embed().setTitle(`${h.emoji} NattaBot • ${h.label}`).setDescription(h.text);
}
const helpMenu = () => new ActionRowBuilder().addComponents(
  new StringSelectMenuBuilder().setCustomId('help:menu').setPlaceholder('Pilih kategori…')
    .addOptions(Object.entries(HELP).map(([value, h]) => ({ label: h.label, value, emoji: h.emoji }))));

module.exports = [
  {
    data: new SlashCommandBuilder().setName('help').setDescription('Daftar perintah NattaBot'),
    async execute(i) { await i.reply({ embeds: [helpEmbed('home')], components: [helpMenu()], ephemeral: true }); },
  },
  {
    data: new SlashCommandBuilder().setName('ping').setDescription('Cek kecepatan respons bot'),
    async execute(i) {
      const t = Date.now(); await i.deferReply({ ephemeral: true });
      await i.editReply({ embeds: [embed('accent').setTitle('🏓 Pong!').addFields(
        { name: 'Respons', value: `\`${Date.now() - t} ms\``, inline: true },
        { name: 'Gateway', value: `\`${Math.round(i.client.ws.ping)} ms\``, inline: true })] });
    },
  },
  {
    data: new SlashCommandBuilder().setName('botinfo').setDescription('Informasi & statistik bot'),
    async execute(i) {
      const c = i.client; const mem = process.memoryUsage().rss / 1024 / 1024;
      await i.reply({ ephemeral: true, embeds: [embed().setTitle('NATTABOT').setThumbnail(c.user.displayAvatarURL())
        .setDescription('Ultimate Private Premium Discord Bot')
        .addFields(
          { name: 'Uptime', value: fmtDuration(c.uptime), inline: true },
          { name: 'Server', value: String(c.guilds.cache.size), inline: true },
          { name: 'Ping', value: `${Math.round(c.ws.ping)} ms`, inline: true },
          { name: 'RAM', value: `${mem.toFixed(0)} MB`, inline: true },
          { name: 'CPU', value: `${os.loadavg()[0].toFixed(2)} load`, inline: true },
          { name: 'Versi', value: `Node ${process.version} • discord.js ${djsVersion}`, inline: true })] });
    },
  },
  {
    data: new SlashCommandBuilder().setName('profile').setDescription('Profil Natta seorang anggota')
      .addUserOption((o) => o.setName('user').setDescription('Anggota (default: kamu)')),
    async execute(i) {
      const user = i.options.getUser('user') ?? i.user;
      if (user.bot) return i.reply({ content: 'Bot tidak punya profil.', ephemeral: true });
      const u = eco.getUser(user.id); const s = slot.userStats(user.id);
      const m = await i.guild?.members.fetch(user.id).catch(() => null);
      await i.reply({ embeds: [embed().setTitle(`PROFIL • ${m?.displayName ?? user.username}`).setThumbnail(user.displayAvatarURL({ size: 256 }))
        .addFields(
          { name: '🪙 Saldo', value: nc(u.balance), inline: true },
          { name: '🏆 Peringkat', value: `#${eco.rank(user.id)}`, inline: true },
          { name: '🔥 Streak Daily', value: `${u.streak} hari`, inline: true },
          { name: '🎰 Slot', value: `${s.spins} putaran • ${s.wins} menang • terbesar ${nc(s.biggest_win)}` },
          { name: 'Bergabung di server', value: m?.joinedTimestamp ? relTime(m.joinedTimestamp) : '—', inline: true })] });
    },
  },
  {
    data: new SlashCommandBuilder().setName('serverinfo').setDescription('Informasi server ini').setDMPermission(false),
    async execute(i) {
      const g = i.guild; await g.fetch();
      await i.reply({ embeds: [embed().setTitle(g.name.toUpperCase()).setThumbnail(g.iconURL({ size: 256 }))
        .addFields(
          { name: 'Pemilik', value: `<@${g.ownerId}>`, inline: true },
          { name: 'Anggota', value: g.memberCount.toLocaleString('id-ID'), inline: true },
          { name: 'Channel', value: String(g.channels.cache.size), inline: true },
          { name: 'Role', value: String(g.roles.cache.size), inline: true },
          { name: 'Boost', value: `Level ${g.premiumTier} (${g.premiumSubscriptionCount ?? 0})`, inline: true },
          { name: 'Dibuat', value: relTime(g.createdTimestamp), inline: true })] });
    },
  },
];
module.exports.helpEmbed = helpEmbed; module.exports.helpMenu = helpMenu;

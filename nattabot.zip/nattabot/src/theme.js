const { EmbedBuilder } = require('discord.js');
const cfg = require('./config');

const FOOTER = 'NattaBot • Exclusive Private Bot';
const nc = (n) => `${Number(n).toLocaleString('id-ID')} NC`;

function embed(color = 'primary') {
  return new EmbedBuilder()
    .setColor(cfg.colors[color] ?? color)
    .setFooter({ text: FOOTER })
    .setTimestamp();
}
const ok = (title, desc) => embed('success').setTitle(`✦ ${title}`).setDescription(desc);
const err = (title, desc) => embed('danger').setTitle(`✕ ${title}`).setDescription(desc);
const warn = (title, desc) => embed('warn').setTitle(`⚠ ${title}`).setDescription(desc);
const VIRTUAL_NOTE = '*Natta Coins adalah mata uang virtual di dalam bot, tanpa nilai uang asli.*';

function relTime(ts) { return `<t:${Math.floor(ts / 1000)}:R>`; }
function fmtDuration(ms) {
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  return [d && `${d}h`, h && `${h}j`, m && `${m}m`, `${sec}d`].filter(Boolean).join(' ');
}
module.exports = { embed, ok, err, warn, nc, VIRTUAL_NOTE, relTime, fmtDuration, FOOTER };

const { db } = require('../db');
const cfg = require('../config');

const E = cfg.economy;
const today = () => new Date().toLocaleDateString('sv-SE', { timeZone: process.env.TZ || 'Asia/Jakarta' });
const rand = (a, b) => require('crypto').randomInt(a, b + 1);

const stmt = {
  ensure: db.prepare('INSERT OR IGNORE INTO users(user_id, created_at) VALUES(?, ?)'),
  get: db.prepare('SELECT * FROM users WHERE user_id = ?'),
  tx: db.prepare('INSERT INTO transactions(user_id,type,amount,balance_after,note,created_at) VALUES(?,?,?,?,?,?)'),
};

function getUser(id) { stmt.ensure.run(id, Date.now()); return stmt.get.get(id); }

// SEMUA perubahan saldo lewat fungsi ini. Sinkron + di dalam transaksi SQLite = anti duplikasi / race condition.
function applyDelta(userId, delta, type, note = null) {
  const u = getUser(userId);
  const next = u.balance + delta;
  if (next < 0) throw new Error('INSUFFICIENT');
  db.prepare('UPDATE users SET balance = ?, total_earned = total_earned + ?, total_spent = total_spent + ? WHERE user_id = ?')
    .run(next, delta > 0 ? delta : 0, delta < 0 ? -delta : 0, userId);
  stmt.tx.run(userId, type, delta, next, note, Date.now());
  return next;
}
const adjust = db.transaction((userId, delta, type, note) => applyDelta(userId, delta, type, note));

const claimDaily = db.transaction((userId) => {
  const u = getUser(userId); const now = Date.now();
  const wait = u.last_daily + 24 * 3600e3 - now;
  if (wait > 0) return { ok: false, wait };
  const streak = now - u.last_daily <= 48 * 3600e3 && u.last_daily ? Math.min(u.streak + 1, 999) : 1;
  const bonus = (Math.min(streak, E.dailyStreakMax) - 1) * E.dailyStreakStep;
  let surprise = 0;
  if (Math.random() < E.surpriseChance) surprise = Math.round(rand(E.surpriseMin, E.surpriseMax) / 100) * 100;
  const total = E.dailyBase + bonus + surprise;
  db.prepare('UPDATE users SET last_daily = ?, streak = ? WHERE user_id = ?').run(now, streak, userId);
  const bal = applyDelta(userId, total, 'daily', `streak ${streak}${surprise ? ' + kejutan' : ''}`);
  return { ok: true, base: E.dailyBase, bonus, surprise, total, streak, balance: bal };
});

const claimWeekly = db.transaction((userId) => {
  const u = getUser(userId); const now = Date.now();
  const wait = u.last_weekly + 7 * 24 * 3600e3 - now;
  if (wait > 0) return { ok: false, wait };
  db.prepare('UPDATE users SET last_weekly = ? WHERE user_id = ?').run(now, userId);
  const bal = applyDelta(userId, E.weeklyReward, 'weekly', null);
  return { ok: true, total: E.weeklyReward, balance: bal };
});

const transfer = db.transaction((fromId, toId, amount) => {
  if (fromId === toId) return { ok: false, reason: 'Tidak bisa transfer ke diri sendiri.' };
  if (!Number.isInteger(amount) || amount < E.transferMin || amount > E.transferMax)
    return { ok: false, reason: `Nominal harus ${E.transferMin.toLocaleString('id-ID')}–${E.transferMax.toLocaleString('id-ID')} NC.` };
  const u = getUser(fromId); getUser(toId);
  const now = Date.now();
  if (now - u.last_transfer < E.transferCooldownMs) return { ok: false, reason: 'Tunggu sebentar sebelum transfer lagi (anti-spam).' };
  const day = today();
  const sum = (u.transfer_day === day ? u.transfer_sum : 0) + amount;
  if (sum > E.transferDailyLimit) return { ok: false, reason: `Batas transfer harian ${E.transferDailyLimit.toLocaleString('id-ID')} NC tercapai.` };
  if (u.balance < amount) return { ok: false, reason: 'Saldo tidak cukup.' };
  db.prepare('UPDATE users SET last_transfer=?, transfer_day=?, transfer_sum=? WHERE user_id=?').run(now, day, sum, fromId);
  const balFrom = applyDelta(fromId, -amount, 'transfer_out', `ke ${toId}`);
  applyDelta(toId, amount, 'transfer_in', `dari ${fromId}`);
  return { ok: true, balance: balFrom };
});

// Hadiah aktivitas chat: anti-spam (cooldown + batas harian)
const activeReward = db.transaction((userId) => {
  const u = getUser(userId); const now = Date.now(); const day = today();
  const count = u.active_day === day ? u.active_count : 0;
  if (now - u.last_active_reward < E.activeCooldownMs || count >= E.activeDailyCap) return 0;
  db.prepare('UPDATE users SET last_active_reward=?, active_day=?, active_count=? WHERE user_id=?').run(now, day, count + 1, userId);
  applyDelta(userId, E.activeReward, 'active', null);
  return E.activeReward;
});

const history = (userId, limit = 10) => db.prepare('SELECT * FROM transactions WHERE user_id=? ORDER BY id DESC LIMIT ?').all(userId, limit);
const top = (limit = 10) => db.prepare('SELECT user_id, balance FROM users ORDER BY balance DESC LIMIT ?').all(limit);
const rank = (userId) => db.prepare('SELECT COUNT(*)+1 AS r FROM users WHERE balance > (SELECT balance FROM users WHERE user_id=?)').get(userId).r;

module.exports = { getUser, adjust, claimDaily, claimWeekly, transfer, activeReward, history, top, rank, today };

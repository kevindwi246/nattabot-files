const path = require('path');
const { createCanvas, loadImage } = require('@napi-rs/canvas');
const { FONT, roundRect, avatar } = require('./cardGen');

const TEMPLATE_PATH = path.join(__dirname, '../../assets/news_template.jpg');
const S = 2; // supersampling → output 1472×828 (HD)
// Koordinat area pada template asli 736×414 (hasil pengukuran piksel greenscreen)
const GREEN = { x: 206, y: 60, w: 491, h: 220 };
const STRIP = { x: 208, y: 303, w: 489, h: 33 };
const BANNER = { x: 186, y: 351, w: 550, h: 47 };

const TEMPLATES = {
  classic: { name: 'Classic Headline', desc: 'Headline di strip putih di bawah layar utama.' },
  ticker: { name: 'Live Ticker', desc: 'Headline besar di banner biru bawah + jam siaran di strip.' },
  alert: { name: 'Red Alert', desc: 'Nuansa merah darurat dengan headline di strip.' },
};

let tpl = null;
async function getTemplate() { return (tpl ??= await loadImage(TEMPLATE_PATH)); }

function wrap(ctx, text, maxW) {
  const words = text.split(/\s+/); const lines = []; let cur = '';
  for (const w of words) {
    const t = cur ? `${cur} ${w}` : w;
    if (ctx.measureText(t).width <= maxW || !cur) cur = t; else { lines.push(cur); cur = w; }
  }
  if (cur) lines.push(cur);
  return lines;
}

// Cari ukuran font terbesar yang muat → teks tidak pernah keluar area.
function drawFitted(ctx, text, box, { maxFont, minFont = 10, maxLines = 2, color, align = 'center', italic = false, weight = '800' }) {
  const pad = 10 * S; const bx = box.x * S, by = box.y * S, bw = box.w * S, bh = box.h * S;
  const maxW = bw - pad * 2;
  let size = maxFont * S, lines = [text], lh = 0;
  for (; size >= minFont * S; size -= S / 2) {
    ctx.font = `${italic ? 'italic ' : ''}${weight} ${size}px ${FONT}`;
    lines = wrap(ctx, text, maxW); lh = size * 1.12;
    if (lines.length <= maxLines && lines.length * lh <= bh - 4 * S && lines.every((l) => ctx.measureText(l).width <= maxW)) break;
  }
  ctx.save();
  ctx.beginPath(); ctx.rect(bx, by, bw, bh); ctx.clip();
  ctx.fillStyle = color; ctx.textBaseline = 'middle'; ctx.textAlign = align;
  const startY = by + bh / 2 - ((lines.length - 1) * lh) / 2;
  const x = align === 'center' ? bx + bw / 2 : bx + pad;
  lines.forEach((l, i) => ctx.fillText(l, x, startY + i * lh));
  ctx.restore();
}

async function makeNews({ text, avatarUrl, template = 'classic' }) {
  if (!TEMPLATES[template]) template = 'classic';
  const img = await getTemplate();
  const c = createCanvas(img.width * S, img.height * S); const ctx = c.getContext('2d');
  ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(img, 0, 0, c.width, c.height);

  if (template === 'alert') { // tint merah pada seluruh studio, lalu bar merah template tetap terbaca
    ctx.fillStyle = 'rgba(190,0,25,0.30)'; ctx.fillRect(0, 0, c.width, c.height);
  }

  // === Greenscreen → foto profil ===
  const g = { x: GREEN.x * S, y: GREEN.y * S, w: GREEN.w * S, h: GREEN.h * S };
  const av = await avatar(avatarUrl);
  ctx.save(); ctx.beginPath(); ctx.rect(g.x, g.y, g.w, g.h); ctx.clip();
  if (av) {
    const cover = Math.max(g.w / av.width, g.h / av.height);
    try { ctx.filter = 'blur(26px)'; } catch {}
    ctx.drawImage(av, g.x + (g.w - av.width * cover) / 2, g.y + (g.h - av.height * cover) / 2, av.width * cover, av.height * cover);
    ctx.filter = 'none';
    ctx.fillStyle = 'rgba(5,10,40,0.35)'; ctx.fillRect(g.x, g.y, g.w, g.h);
    const side = g.h; // foto utuh di tengah, tinggi penuh
    ctx.drawImage(av, g.x + (g.w - side) / 2, g.y, side, side);
  } else { ctx.fillStyle = '#0a1030'; ctx.fillRect(g.x, g.y, g.w, g.h); }
  const vg = ctx.createLinearGradient(0, g.y, 0, g.y + g.h);
  vg.addColorStop(0, 'rgba(255,255,255,0.10)'); vg.addColorStop(0.5, 'rgba(255,255,255,0)'); vg.addColorStop(1, 'rgba(0,0,20,0.35)');
  ctx.fillStyle = vg; ctx.fillRect(g.x, g.y, g.w, g.h);
  ctx.restore();

  const nowStr = new Date().toLocaleTimeString('id-ID', { timeZone: process.env.TZ || 'Asia/Jakarta', hour: '2-digit', minute: '2-digit' }).replace('.', ':');

  if (template === 'ticker') {
    // Banner bawah diganti banner baru berisi headline
    const b = { x: BANNER.x * S, y: BANNER.y * S, w: BANNER.w * S, h: BANNER.h * S };
    const bg = ctx.createLinearGradient(0, b.y, 0, b.y + b.h);
    bg.addColorStop(0, '#1238d8'); bg.addColorStop(1, '#06165e');
    ctx.fillStyle = bg; ctx.fillRect(b.x, b.y, b.w, b.h);
    ctx.fillStyle = 'rgba(255,255,255,0.55)'; ctx.fillRect(b.x, b.y, b.w, 2 * S);
    drawFitted(ctx, text.toUpperCase(), { x: BANNER.x + 6, y: BANNER.y + 2, w: BANNER.w - 12, h: BANNER.h - 4 },
      { maxFont: 24, minFont: 10, maxLines: 2, color: '#ffffff', italic: true });
    drawFitted(ctx, `NATTA NEWS  •  ${nowStr} WIB  •  LIVE`, STRIP,
      { maxFont: 15, minFont: 9, maxLines: 1, color: '#0a1f6b', weight: '700' });
  } else {
    drawFitted(ctx, text.toUpperCase(), STRIP, { maxFont: 22, minFont: 9, maxLines: 2, color: '#0a1f6b' });
  }
  return c.toBuffer('image/png');
}
module.exports = { makeNews, TEMPLATES };

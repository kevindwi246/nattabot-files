const crypto = require('crypto');
const { db, getKv, setKv } = require('../db');
const cfg = require('../config');
const eco = require('./economy');

const S = cfg.slot;
// Bobot simbol & pembayaran: TRANSPARAN, sama untuk semua pemain, tanpa manipulasi tersembunyi.
const SYMBOLS = [
  { id: 'cherry', emoji: '🍒', name: 'Cherry', weight: 22, mult: 3, tier: 'Hadiah kecil' },
  { id: 'lemon', emoji: '🍋', name: 'Lemon', weight: 20, mult: 4, tier: 'Hadiah kecil' },
  { id: 'grape', emoji: '🍇', name: 'Grape', weight: 16, mult: 6, tier: 'Hadiah menengah' },
  { id: 'watermelon', emoji: '🍉', name: 'Watermelon', weight: 14, mult: 8, tier: 'Hadiah menengah' },
  { id: 'star', emoji: '⭐', name: 'Star', weight: 9, mult: 15, tier: 'Hadiah besar' },
  { id: 'diamond', emoji: '💎', name: 'Diamond', weight: 7, mult: 30, tier: 'JACKPOT' },
  { id: 'crown', emoji: '👑', name: 'Crown', weight: 5, mult: 60, tier: 'SUPER JACKPOT' },
  { id: 'seven', emoji: '7️⃣', name: 'Lucky Seven', weight: 3, mult: 150, tier: 'MEGA JACKPOT (+ Jackpot Progresif)' },
];
const TOTAL = SYMBOLS.reduce((a, s) => a + s.weight, 0);

function pick() {
  let r = crypto.randomInt(0, TOTAL);
  for (const s of SYMBOLS) { if ((r -= s.weight) < 0) return s; }
  return SYMBOLS[0];
}

// RTP dihitung langsung dari tabel di atas (bukan angka karangan).
function stats() {
  let triple = 0, rtp = 0, pairP = 0;
  for (const s of SYMBOLS) {
    const p = s.weight / TOTAL;
    triple += p ** 3; rtp += p ** 3 * s.mult;
    pairP += 3 * p * p * (1 - p);
  }
  rtp += pairP * S.pairMultiplier;
  return { pTriple: triple, pPair: pairP, pWin: triple + pairP, rtp };
}

const getPool = () => parseInt(getKv('jackpot_pool', String(S.jackpotSeed)), 10);
const ensureStats = db.prepare('INSERT OR IGNORE INTO slot_stats(user_id) VALUES(?)');

const spinTx = db.transaction((userId, bet, free) => {
  const u = eco.getUser(userId);
  if (free) {
    if (u.free_spins < 1) throw new Error('NO_FREE_SPIN');
    db.prepare('UPDATE users SET free_spins = free_spins - 1 WHERE user_id = ?').run(userId);
  } else if (u.balance < bet) throw new Error('INSUFFICIENT');

  const reels = [pick(), pick(), pick()];
  let mult = 0, label = 'Zonk';
  const [a, b, c] = reels;
  if (a.id === b.id && b.id === c.id) { mult = a.mult; label = `3× ${a.name} — ${a.tier}`; }
  else if (a.id === b.id || b.id === c.id || a.id === c.id) { mult = S.pairMultiplier; label = `Sepasang! (${S.pairMultiplier}×)`; }

  let payout = bet * mult;
  let jackpotWon = 0, luckyBonus = 0;
  const isSeven = mult === 150;
  if (isSeven) { jackpotWon = getPool(); payout += jackpotWon; setKv('jackpot_pool', S.jackpotSeed); }
  if (payout > 0) {
    const day = eco.today();
    if (u.lucky_day !== day) { // bonus keberuntungan harian: kemenangan pertama setiap hari +25%
      luckyBonus = Math.floor(payout * S.luckyBonus);
      payout += luckyBonus;
      db.prepare('UPDATE users SET lucky_day = ? WHERE user_id = ?').run(day, userId);
    }
  }
  if (!free) { // 2% taruhan masuk jackpot progresif
    eco.adjust(userId, -bet, 'slot_bet', null);
    if (!isSeven) setKv('jackpot_pool', getPool() + Math.max(1, Math.floor(bet * S.jackpotContribution)));
  }
  let balance = eco.getUser(userId).balance;
  if (payout > 0) balance = eco.adjust(userId, payout, free ? 'slot_free_win' : 'slot_win', label);

  ensureStats.run(userId);
  db.prepare(`UPDATE slot_stats SET spins=spins+1, wins=wins+?, losses=losses+?, total_bet=total_bet+?, total_won=total_won+?,
    biggest_win=MAX(biggest_win,?), jackpots=jackpots+? WHERE user_id=?`)
    .run(payout > 0 ? 1 : 0, payout > 0 ? 0 : 1, free ? 0 : bet, payout, payout, mult >= 30 ? 1 : 0, userId);
  db.prepare('INSERT INTO slot_history(user_id,bet,reels,payout,free,created_at) VALUES(?,?,?,?,?,?)')
    .run(userId, bet, reels.map((r) => r.emoji).join(' '), payout, free ? 1 : 0, Date.now());
  return { reels, mult, label, payout, jackpotWon, luckyBonus, balance, bet, free, bigWin: mult >= 15 };
});

const claimFreeSpins = db.transaction((userId) => {
  const u = eco.getUser(userId); const now = Date.now();
  const wait = u.last_freespin + 24 * 3600e3 - now;
  if (wait > 0) return { ok: false, wait, have: u.free_spins };
  db.prepare('UPDATE users SET free_spins = free_spins + ?, last_freespin = ? WHERE user_id = ?').run(S.freeSpinsPerClaim, now, userId);
  return { ok: true, have: u.free_spins + S.freeSpinsPerClaim };
});

const userStats = (id) => { ensureStats.run(id); return db.prepare('SELECT * FROM slot_stats WHERE user_id=?').get(id); };
const recent = (id, n = 8) => db.prepare('SELECT * FROM slot_history WHERE user_id=? ORDER BY id DESC LIMIT ?').all(id, n);
const leaderboard = (n = 10) => db.prepare('SELECT * FROM slot_stats WHERE spins > 0 ORDER BY total_won DESC LIMIT ?').all(n);

module.exports = { SYMBOLS, spin: spinTx, claimFreeSpins, stats, getPool, userStats, recent, leaderboard, pick };

const path = require('path');
const fs = require('fs');
const { createCanvas, loadImage, GlobalFonts } = require('@napi-rs/canvas');

const fontDir = path.join(__dirname, '../../assets/fonts');
if (fs.existsSync(fontDir)) {
  for (const f of fs.readdirSync(fontDir)) {
    if (/\.(ttf|otf)$/i.test(f)) { try { GlobalFonts.registerFromPath(path.join(fontDir, f)); } catch {} }
  }
}
const FONT = '"Montserrat", "Poppins", "Inter", "Roboto", "DejaVu Sans", "Liberation Sans", Arial, sans-serif';

function fit(ctx, text, maxW, size, weight = '800', min = 18) {
  let s = size;
  do { ctx.font = `${weight} ${s}px ${FONT}`; s -= 2; } while (ctx.measureText(text).width > maxW && s > min);
  return text;
}
function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
}
async function avatar(url) {
  try { return await loadImage(url); } catch { return null; }
}

/**
 * Kartu premium 1200×420. mode: 'join' (violet–cyan) atau 'leave' (merah–amber redup).
 */
async function makeCard({ mode, avatarUrl, displayName, username, memberNo, guildName }) {
  const W = 1200, H = 420;
  const c = createCanvas(W, H); const ctx = c.getContext('2d');
  const join = mode === 'join';
  const pal = join
    ? { a: '#080a18', b: '#1a1147', c: '#0a3a52', accent: '#00e5ff', accent2: '#7c5cff' }
    : { a: '#120a10', b: '#2a1020', c: '#3a1f0f', accent: '#ff6b81', accent2: '#ffb347' };

  const g = ctx.createLinearGradient(0, 0, W, H);
  g.addColorStop(0, pal.a); g.addColorStop(0.55, pal.b); g.addColorStop(1, pal.c);
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);

  // glow orbs
  for (const [x, y, r, col] of [[160, 60, 260, pal.accent2], [1080, 380, 300, pal.accent]]) {
    const rg = ctx.createRadialGradient(x, y, 0, x, y, r);
    rg.addColorStop(0, col + '55'); rg.addColorStop(1, col + '00');
    ctx.fillStyle = rg; ctx.fillRect(0, 0, W, H);
  }
  // garis grid halus futuristik
  ctx.strokeStyle = 'rgba(255,255,255,0.035)'; ctx.lineWidth = 1;
  for (let x = 0; x < W; x += 40) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke(); }
  for (let y = 0; y < H; y += 40) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }

  // panel kaca
  roundRect(ctx, 36, 36, W - 72, H - 72, 28);
  ctx.fillStyle = 'rgba(255,255,255,0.045)'; ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,0.14)'; ctx.lineWidth = 2; ctx.stroke();

  // avatar + ring gradien
  const cx = 230, cy = H / 2, R = 118;
  const ring = ctx.createLinearGradient(cx - R, cy - R, cx + R, cy + R);
  ring.addColorStop(0, pal.accent); ring.addColorStop(1, pal.accent2);
  ctx.shadowColor = pal.accent; ctx.shadowBlur = 36;
  ctx.beginPath(); ctx.arc(cx, cy, R + 9, 0, Math.PI * 2); ctx.fillStyle = ring; ctx.fill();
  ctx.shadowBlur = 0;
  ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.closePath(); ctx.clip();
  const img = await avatar(avatarUrl);
  if (img) ctx.drawImage(img, cx - R, cy - R, R * 2, R * 2);
  else { ctx.fillStyle = '#222'; ctx.fillRect(cx - R, cy - R, R * 2, R * 2); }
  ctx.restore();
  if (!join) { // goodbye: avatar sedikit meredup
    ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.fillStyle = 'rgba(10,5,10,0.28)'; ctx.fill(); ctx.restore();
  }

  const tx = 400, maxW = W - tx - 90;
  ctx.textBaseline = 'alphabetic'; ctx.textAlign = 'left';
  ctx.fillStyle = pal.accent; ctx.font = `700 24px ${FONT}`;
  ctx.fillText((join ? 'N A T T A   •   W E L C O M E' : 'N A T T A   •   F A R E W E L L'), tx, 128);

  const title = join ? 'Selamat Datang' : 'Sampai Jumpa';
  const tg = ctx.createLinearGradient(tx, 0, tx + 500, 0);
  tg.addColorStop(0, '#ffffff'); tg.addColorStop(1, pal.accent);
  ctx.fillStyle = tg; fit(ctx, title, maxW, 70, '800'); ctx.fillText(title, tx, 205);

  ctx.fillStyle = '#ffffff'; fit(ctx, displayName, maxW, 44, '700', 22); ctx.fillText(displayName, tx, 262);
  ctx.fillStyle = 'rgba(255,255,255,0.62)'; fit(ctx, `@${username}`, maxW, 28, '500', 16); ctx.fillText(`@${username}`, tx, 302);

  // chip bawah
  const chip = join ? (memberNo ? `Member #${memberNo.toLocaleString('id-ID')}` : 'Anggota baru') : 'Terima kasih pernah bersama kami';
  ctx.font = `700 22px ${FONT}`;
  const cw = ctx.measureText(chip).width + 44;
  roundRect(ctx, tx, 328, cw, 42, 21);
  const cg = ctx.createLinearGradient(tx, 0, tx + cw, 0); cg.addColorStop(0, pal.accent2 + 'cc'); cg.addColorStop(1, pal.accent + 'cc');
  ctx.fillStyle = cg; ctx.fill();
  ctx.fillStyle = '#05060f'; ctx.fillText(chip, tx + 22, 358);

  ctx.textAlign = 'right'; ctx.fillStyle = 'rgba(255,255,255,0.45)'; fit(ctx, guildName, 360, 20, '600', 14);
  ctx.fillText(guildName, W - 70, H - 62);
  return c.toBuffer('image/png');
}
module.exports = { makeCard, roundRect, fit, FONT, avatar };

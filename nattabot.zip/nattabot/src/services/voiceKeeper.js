const {
  joinVoiceChannel, getVoiceConnection, VoiceConnectionStatus, entersState,
} = require('@discordjs/voice');
const { ChannelType, PermissionFlagsBits } = require('discord.js');
const dbm = require('../db');
const log = require('../logger');
const { embed, relTime } = require('../theme');

const MONITOR_MS = 30_000;

/**
 * Voice Keeper 24/7 — memakai koneksi voice resmi Discord (@discordjs/voice).
 * Bot hanya duduk (self-mute & self-deaf) di channel tujuan; tidak ada trik yang melanggar aturan platform.
 */
class VoiceKeeper {
  constructor(client) {
    this.client = client;
    this.state = new Map(); // guildId -> { attempts, since, lastOk, reconnects, timer, busy }
    this.monitor = null;
  }

  st(guildId) {
    if (!this.state.has(guildId)) this.state.set(guildId, { attempts: 0, since: null, lastOk: null, reconnects: 0, timer: null, busy: false });
    return this.state.get(guildId);
  }

  async start() {
    for (const s of dbm.allGuildSettings()) {
      if (s.voice_enabled && s.voice_channel_id) this.connect(s.guild_id, 'Bot start').catch(() => {});
    }
    this.monitor = setInterval(() => this.check(), MONITOR_MS);
    log.info('VoiceKeeper aktif, monitor tiap', MONITOR_MS / 1000, 'detik');
  }

  async notify(guildId, title, desc, color = 'primary') {
    log.info(`[Voice:${guildId}] ${title} — ${desc}`);
    try {
      const s = dbm.getGuild(guildId);
      if (!s.log_channel_id) return;
      const ch = await this.client.channels.fetch(s.log_channel_id).catch(() => null);
      if (ch?.isTextBased()) await ch.send({ embeds: [embed(color).setTitle(`🎧 ${title}`).setDescription(desc)] });
    } catch (e) { log.warn('notify voice gagal', e.message); }
  }

  async connect(guildId, reason = 'manual') {
    const st = this.st(guildId);
    if (st.busy) return false;
    st.busy = true;
    try {
      const s = dbm.getGuild(guildId);
      if (!s.voice_enabled || !s.voice_channel_id) return false;
      const guild = this.client.guilds.cache.get(guildId);
      if (!guild) return false;
      const channel = await guild.channels.fetch(s.voice_channel_id).catch(() => null);
      if (!channel || ![ChannelType.GuildVoice, ChannelType.GuildStageVoice].includes(channel.type)) {
        await this.notify(guildId, 'Voice channel tidak ditemukan', 'Atur ulang dengan `/setvoice`.', 'danger');
        return false;
      }
      const perms = channel.permissionsFor(guild.members.me);
      if (!perms?.has([PermissionFlagsBits.ViewChannel, PermissionFlagsBits.Connect])) {
        await this.notify(guildId, 'Izin kurang', `Bot butuh izin **View Channel** & **Connect** di ${channel}.`, 'danger');
        return false;
      }

      let conn = getVoiceConnection(guildId);
      if (conn && conn.joinConfig.channelId !== channel.id) { conn.destroy(); conn = null; }
      if (!conn) {
        conn = joinVoiceChannel({
          channelId: channel.id, guildId, adapterCreator: guild.voiceAdapterCreator,
          selfDeaf: true, selfMute: true,
        });
        this.attach(conn, guildId);
      }
      try {
        await entersState(conn, VoiceConnectionStatus.Ready, 30_000);
      } catch {
        try { conn.destroy(); } catch {}
        throw new Error('Timeout menunggu koneksi Ready');
      }
      st.attempts = 0; st.lastOk = Date.now(); st.since ??= Date.now();
      if (reason !== 'monitor') await this.notify(guildId, 'Voice Keeper terhubung', `Masuk ke ${channel}\nAlasan: ${reason}`, 'success');
      return true;
    } catch (e) {
      log.warn(`connect gagal [${guildId}]`, e.message);
      this.schedule(guildId, e.message);
      return false;
    } finally { st.busy = false; }
  }

  attach(conn, guildId) {
    conn.on('stateChange', (o, n) => log.info(`[Voice:${guildId}] ${o.status} → ${n.status}`));
    conn.on(VoiceConnectionStatus.Disconnected, async () => {
      this.notify(guildId, 'Koneksi voice terputus', 'Mencoba memulihkan koneksi…', 'warn');
      try {
        await Promise.race([
          entersState(conn, VoiceConnectionStatus.Signalling, 5_000),
          entersState(conn, VoiceConnectionStatus.Connecting, 5_000),
        ]); // sedang pindah/reconnect otomatis oleh Discord
      } catch {
        try { conn.destroy(); } catch {}
      }
    });
    conn.on(VoiceConnectionStatus.Destroyed, () => {
      const s = dbm.getGuild(guildId);
      if (s.voice_enabled) this.schedule(guildId, 'koneksi dihancurkan');
    });
    conn.on('error', (e) => log.error(`[Voice:${guildId}] error`, e));
  }

  schedule(guildId, why) {
    const st = this.st(guildId);
    if (st.timer) return;
    st.attempts += 1; st.reconnects += 1;
    const delay = Math.min(5_000 * 2 ** Math.min(st.attempts - 1, 5), 120_000);
    log.info(`[Voice:${guildId}] reconnect #${st.attempts} dalam ${delay / 1000}s (${why})`);
    if (st.attempts === 1) this.notify(guildId, 'Gangguan koneksi', `${why}\nReconnect otomatis dijadwalkan.`, 'warn');
    st.timer = setTimeout(() => { st.timer = null; this.connect(guildId, `auto-reconnect #${st.attempts}`).catch(() => {}); }, delay);
  }

  check() {
    for (const s of dbm.allGuildSettings()) {
      if (!s.voice_enabled || !s.voice_channel_id) continue;
      const guild = this.client.guilds.cache.get(s.guild_id);
      if (!guild) continue;
      const conn = getVoiceConnection(s.guild_id);
      const inRightChannel = guild.members.me?.voice?.channelId === s.voice_channel_id;
      const ready = conn?.state.status === VoiceConnectionStatus.Ready;
      if (!(conn && ready && inRightChannel) && !this.st(s.guild_id).timer) {
        this.connect(s.guild_id, 'monitor').catch(() => {});
      }
    }
  }

  async enable(guildId, channelId) {
    if (channelId) dbm.setGuild(guildId, 'voice_channel_id', channelId);
    dbm.setGuild(guildId, 'voice_enabled', 1);
    this.st(guildId).attempts = 0;
    return this.connect(guildId, 'diaktifkan admin');
  }

  disable(guildId) {
    dbm.setGuild(guildId, 'voice_enabled', 0);
    const st = this.st(guildId);
    if (st.timer) { clearTimeout(st.timer); st.timer = null; }
    getVoiceConnection(guildId)?.destroy();
    st.since = null;
    this.notify(guildId, 'Voice Keeper dimatikan', 'Bot keluar dari voice channel.', 'warn');
  }

  // Dipanggil dari voiceStateUpdate saat bot dipindah/dikeluarkan
  onBotVoiceUpdate(oldS, newS) {
    const s = dbm.getGuild(newS.guild.id);
    if (!s.voice_enabled) return;
    if (newS.channelId !== s.voice_channel_id) {
      this.notify(newS.guild.id, 'Bot keluar/dipindah', 'Kembali ke channel tujuan…', 'warn');
      getVoiceConnection(newS.guild.id)?.destroy();
      this.schedule(newS.guild.id, 'bot dipindah atau dikeluarkan');
    }
  }

  status(guildId) {
    const s = dbm.getGuild(guildId);
    const st = this.st(guildId);
    const conn = getVoiceConnection(guildId);
    return { enabled: !!s.voice_enabled, channelId: s.voice_channel_id, connected: conn?.state.status === VoiceConnectionStatus.Ready,
      status: conn?.state.status ?? 'tidak ada koneksi', since: st.since, lastOk: st.lastOk, reconnects: st.reconnects, ping: conn?.ping?.ws ?? null };
  }
}
module.exports = VoiceKeeper;

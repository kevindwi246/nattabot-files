const { REST, Routes } = require('discord.js');
const cfg = require('./config');
const { loadCommands } = require('./loader');

async function deploy() {
  const body = [...loadCommands().values()].map((c) => c.data.toJSON());
  const rest = new REST({ version: '10' }).setToken(cfg.token);
  const route = cfg.guildId ? Routes.applicationGuildCommands(cfg.clientId, cfg.guildId) : Routes.applicationCommands(cfg.clientId);
  await rest.put(route, { body });
  return body.length;
}
module.exports = { deploy };
if (require.main === module) {
  deploy().then((n) => console.log(`✔ ${n} slash command terdaftar (${cfg.guildId ? 'server ' + cfg.guildId : 'global'})`)).catch((e) => { console.error(e); process.exit(1); });
}
